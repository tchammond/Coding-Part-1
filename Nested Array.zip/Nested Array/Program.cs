﻿using System;

namespace Nested_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            object[] numbers = new object[3];
            numbers[0] = 1;
            numbers[1] = new object [2] { 2,new object[1] { 3 } };
            numbers[2] = 4;
       
            Console.WriteLine(FlattenArray(numbers));
        } 
        static object[] FlattenArray(object[] inputArray)
        {
            object[] flattenedArray = { };
            int counter = 0;

            object[] ArrayHelper(object [] inputArray)
            {
                for (int i = 0; i < inputArray.Length; i++)
                {
                    if (ValueType.Equals(inputArray[i], flattenedArray) == true)
                    {
                        object[] arrayLayer = { inputArray[i] };
                        return ArrayHelper(arrayLayer);
                    }

                    else
                    {
                        flattenedArray[counter] = inputArray[i];
                        counter++;
                        return null;
                    }
                }
                return flattenedArray;

            }
            return flattenedArray;

        }
    }
}
